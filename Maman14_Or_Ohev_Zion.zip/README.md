# CLab_Project
Final project for Software Lab with C course in Open University of Israel

By Or Ohev-Zion, 304839376
18.04.24
