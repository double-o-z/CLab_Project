/*  Assembler.h */
#ifndef ASSEMBLER_H
#define ASSEMBLER_H
#include "Helper.h"

void assembleProcess(AssemblerState* state);
void freeAssemblerState(AssemblerState* state);

#endif

